/// <reference path="sco.js" />

$(function () {
    $('body').sco(1, $('object[iudico-type]'));
});